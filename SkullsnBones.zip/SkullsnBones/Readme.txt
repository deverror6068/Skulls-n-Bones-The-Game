Installation du jeu :

Cliquez sur  setup.exe ou Skulls'nBones.application un message vous demandera si vous voulez installer le jeu: cliquez sur installez 
et le jeu se configurera automatiquement, il se peut peut que votre antivirus bloque l'installation ou l'execution du jeu, dans ce cas autorisez le jeu via l'interface de l'antivirus



A noter : Une Connexion internet est requise lors de l'installation 


Désinstallation : 

tapez Skulls'n Bones dans la barre de recherche Window, cliquez droit sur l'icone du jeu et cliquez sur désinstaller , une fenetre s'affiche scrollez jusqu'à arrivé à SkullsnBones 
cliquez droit  et cliquez sur désinstaller et  : le jeu sera désinstallé automatiquement.
